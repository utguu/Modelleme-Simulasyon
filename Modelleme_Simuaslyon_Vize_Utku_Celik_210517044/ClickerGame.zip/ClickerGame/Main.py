import pygame
import random
import math
import time

pygame.init()

# Ekran boyutu ve tam ekran
screen_info = pygame.display.Info()
screen_width, screen_height = screen_info.current_w, screen_info.current_h
screen = pygame.display.set_mode((screen_width, screen_height), pygame.FULLSCREEN)
pygame.display.set_caption("Gold Miner")

# Renkler ve font
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
YELLOW = (255, 215, 0)
RED = (255, 0, 0)
GRAY= (128, 128, 128)
font = pygame.font.Font(None, 36)
clock = pygame.time.Clock()


# Ana Menü Fonksiyonu
def display_menu():
    while True:
        screen.fill(BLACK)
        title_text = font.render("Gold Miner'a Hoş Geldin!", True, YELLOW)
        start_text = font.render("Oyuna Başlamak İçin Enter'a Bas", True, WHITE)
        quit_text = font.render("Çıkış İçin ESC'ye Bas", True, WHITE)

        screen.blit(title_text, (screen_width // 1.999 - title_text.get_width() // 2, screen_height // 2 - 100))
        screen.blit(start_text, (screen_width // 1.999 - start_text.get_width() // 2, screen_height // 2))
        screen.blit(quit_text, (screen_width // 2 - quit_text.get_width() // 2, screen_height // 2 + 50))

        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RETURN:  # Enter'a basıldığında oyuna başla
                    return
                elif event.key == pygame.K_ESCAPE:  # ESC'ye basıldığında çık
                    pygame.quit()
                    exit()


# OYUNUN BAŞINDA ANA MENÜYÜ ÇALIŞTIRMA
display_menu()

# Altın animasyon karelerini yükleme
gold_frames = [
    pygame.image.load("Gold1.jpeg").convert_alpha(),
    pygame.image.load("Gold2.jpeg").convert_alpha(),
    pygame.image.load("Gold3.jpeg").convert_alpha(),
    pygame.image.load("Gold4.jpeg").convert_alpha(),
    pygame.image.load("Gold5.jpeg").convert_alpha()
]
current_frame = 0
animation_speed = 0.1
gold_button_rect = gold_frames[0].get_rect(center=(200, screen_height // 2))

# Altın ve oyun bilgileri
gold_count = 0
click_value = 1
click_multiplier = 1
total_clicks = 0
feedback_message = ""
feedback_messages = [
    "Altına tıkladın!", "Maden kazdın!", "Zengin oluyorsun!",
    "Daha fazla altın buldun!", "Parıldayan bir külçe!",
    "Altın dolusu bir sepet!", "Kazmaya devam et!"
]

# İşçi çeşitleri
workers = [
    {"name": "Çırak Madenci", "cost": 10, "gold_per_second": 1, "count": 0},
    {"name": "Deneyimli Madenci", "cost": 50, "gold_per_second": 5, "count": 0},
    {"name": "Usta Madenci", "cost": 200, "gold_per_second": 20, "count": 0}
]

# Karakter ve ekipmanlar
character_sprites = [pygame.image.load(f"basicCharacter{i}.png").convert_alpha() for i in range(1, 8)]
base_character_sprites = character_sprites[:]  # Orijinal sprite'ları koru
current_character_sprite = 0  # İlk sprite (basicCharacter1)
character_power = 0  # Başlangıç gücü

# Ekipman listesi, maliyet ve güç artışları
equipment_names = ["Silah", "Gövde Zırhı", "Omuz Zırhı", "Bacak Zırhı", "Ayakkabı", "Yeni Karakter"]
base_equipment_costs = [20, 40, 60, 80, 100, 120]  # Altın maliyetleri düşük tutuldu
base_equipment_powers = [5, 15, 10, 15, 20, 25]  # Güç değerleri rekabetçi hale getirildi
equipment_owned = []  # Satın alınan ekipmanları takip etmek için liste
equipment_level = 1    # Ekipman seviyesi (her döngüde artar)

# Sağlık değişkenleri
max_health = 100
current_health = max_health
base_health_regen = 1.0  # Başlangıç sağlık yenileme oranı
D_max = 100  # Düşman hasarının ulaşabileceği maksimum sınır
k = 0.009   # Logistic growth katsayısı
t_0 = 500  # Düşman hasarının hızlı artmaya başladığı süre
start_time = time.time()

# Sağ üst buton yerleşimleri
show_worker_window = False
show_equipment_window = False
worker_button_rect = pygame.Rect(screen_width - 150, 20, 90, 50)
upgrade_button_rect = pygame.Rect(screen_width - 240, 90, 255, 50)
equipment_button_rect = pygame.Rect(screen_width - 240, 160, 255, 50)  # Ekipman butonu
worker_window_rect = pygame.Rect(screen_width - 400, 170, 400, 400)  # İşçi penceresi
equipment_window_rect = pygame.Rect(screen_width - 400, 170, 500, 500)  # Ekipman penceresi

# Zamanlayıcı
running = True
last_health_update = pygame.time.get_ticks()
last_worker_update = pygame.time.get_ticks()

# Seviyeyi artırma ve ekipmanları sıfırdan başlatma
def level_up_equipment():
    global equipment_level, character_sprites, base_equipment_powers, base_equipment_costs
    equipment_level += 1
    # Ekipman güç ve maliyetleri hesapları
    base_equipment_costs = [int(cost * 1.2) for cost in base_equipment_costs]
    base_equipment_powers = [int(power * 1.2) for power in base_equipment_powers]
    # Karakteri sıfırdan giydirmek için sprite’ları orijinal halleriyle sıfırlama
    character_sprites = base_character_sprites[:]

# Oyun döngüsü
while running:
    screen.fill(BLACK)

    # Altın animasyonunu sol ortaya yerleştirme
    current_frame = (current_frame + animation_speed) % len(gold_frames)
    screen.blit(gold_frames[int(current_frame)], (gold_button_rect.x, gold_button_rect.y))

    # Altın ve tıklama sayısını sol üst köşeye yerleştirme
    score_text = font.render(f"Gold: {gold_count}", True, WHITE)
    click_text = font.render(f"Tıklama Sayısı: {total_clicks}", True, WHITE)
    screen.blit(score_text, (20, 20))
    screen.blit(click_text, (20, 60))

    # Gücü ekranın alt ortasına yerleştirme
    power_text = font.render(f"Güç: {character_power}", True, WHITE)
    screen.blit(power_text, (screen_width // 2 - power_text.get_width() // 2, screen_height - 50))

    # Lojistik büyüme ile düşman hasarını hesaplama
    elapsed_time = time.time() - start_time
    enemy_damage = D_max / (1 + math.exp(-k * (elapsed_time - t_0)))
    #print(elapsed_time -t_0)
    #enemy_damage= math.log(elapsed_time+2)


    # Sağlık yenilenme hızını hesaplama
    health_regen_rate = base_health_regen + 0.5 * math.log(1 + character_power)

    # Sağlık barını sağ alt köşeye yerleştirme
    health_bar_width = 200
    health_bar_height = 30
    health_bar_x = screen_width - health_bar_width - 20
    health_bar_y = screen_height - health_bar_height - 20
    pygame.draw.rect(screen, RED, (health_bar_x, health_bar_y, health_bar_width, health_bar_height))
    health_percentage = current_health / max_health
    pygame.draw.rect(screen, WHITE, (health_bar_x, health_bar_y, health_bar_width * health_percentage, health_bar_height))
    health_text = font.render(f"Health: {int(current_health)}", True, BLACK)
    screen.blit(health_text, (health_bar_x + 10, health_bar_y + 5))

    # Sağlık yenilenme ve düşman hasarı göstergesi
    regen_text = font.render(f"Yenilenme: {health_regen_rate:.2f}", True, WHITE)
    damage_text = font.render(f"Hasar: {enemy_damage:.2f}", True, WHITE)
    screen.blit(regen_text, (health_bar_x, health_bar_y - 60))
    screen.blit(damage_text, (health_bar_x, health_bar_y - 30))

    # Sağ üst köşedeki butonlar
    pygame.draw.rect(screen, YELLOW, worker_button_rect, 2)
    pygame.draw.rect(screen, YELLOW, upgrade_button_rect, 2)
    pygame.draw.rect(screen, YELLOW, equipment_button_rect, 2)  # Ekipman butonu
    worker_text = font.render("İşçiler", True, WHITE)
    upgrade_text = font.render("Tıklama Yükseltmesi", True, WHITE)
    equipment_text = font.render("Ekipmanlar", True, WHITE)
    screen.blit(worker_text, (worker_button_rect.x + 10, worker_button_rect.y + 10))
    screen.blit(upgrade_text, (upgrade_button_rect.x + 5, upgrade_button_rect.y + 10))
    screen.blit(equipment_text, (equipment_button_rect.x + 5, equipment_button_rect.y + 10))

    # Karakteri ekranda gösterme (mevcut sprite)
    sprite_index = min(len(equipment_owned), len(character_sprites) - 1)  # Son ekipman alınana kadar ilerler
    screen.blit(character_sprites[sprite_index], (screen_width // 2 - character_sprites[sprite_index].get_width() // 2, screen_height // 2 - character_sprites[sprite_index].get_height() // 2))

    # İşçi penceresi açıkken işçi seçeneklerini gösterme
    if show_worker_window:

        pygame.draw.rect(screen, GRAY, worker_window_rect)
        pygame.draw.rect(screen, YELLOW, worker_window_rect, 2)

        worker_y = worker_window_rect.y + 10
        for worker in workers:
            # Worker kutusunu oluşturma
            worker_rect = pygame.Rect(worker_window_rect.x, worker_y, worker_window_rect.width, 70)

            # Kutunun içini gri renk ile doldurma
            pygame.draw.rect(screen, GRAY, worker_rect)

            # Kenarlığı sarı çiz (iç dikdörtgenden sonra çiziyoruz)
            pygame.draw.rect(screen, YELLOW, worker_rect, 3)

            # Worker metnini oluşturma
            worker_text = font.render(f"{worker['name']}: {worker['count']} - {worker['gold_per_second']} altın/sn",
                                      True, WHITE)
            cost_text = font.render(f"({worker['cost']} altın)", True, WHITE)

            # Worker metninin boyutlarını alma
            worker_text_rect = worker_text.get_rect()
            cost_text_rect = cost_text.get_rect()

            # Worker metnini sola hizala ve dikeyde ortalama
            worker_text_rect.x = worker_rect.x + 15  # Sola hizala (15 piksel içeri kaydır)
            worker_text_rect.centery = worker_rect.centery - 10  # Dikeyde ortala

            # Cost metnini sola hizala ve dikeyde ortalama (worker metninin hemen altında)
            cost_text_rect.x = worker_rect.x + 15
            cost_text_rect.centery = worker_rect.centery + 10

            # Metinleri ekrana çizme
            screen.blit(worker_text, worker_text_rect)
            screen.blit(cost_text, cost_text_rect)

            # Sonraki worker için Y pozisyonunu güncelleme
            worker_y += 85

    # Ekipman penceresi açıkken ekipmanları gösterme
    if show_equipment_window:
        pygame.draw.rect(screen, GRAY, equipment_window_rect)
        pygame.draw.rect(screen, YELLOW, equipment_window_rect, 2)

        equipment_y = equipment_window_rect.y + 15
        for i, name in enumerate(equipment_names):
            # Ekipman kutusunu oluşturma
            equipment_rect = pygame.Rect(equipment_window_rect.x, equipment_y, equipment_window_rect.width, 60)
            pygame.draw.rect(screen, YELLOW, equipment_rect, 2)

            # Metni oluştur ve boyutlarını alma
            equipment_text = font.render(f"{name}: {base_equipment_costs[i]} altın (+{base_equipment_powers[i]} güç)",
                                         True, WHITE)
            text_rect = equipment_text.get_rect()

            # Yatayda sola hizalamak için X pozisyonu sabit, dikeyde ortalamak için Y pozisyonunu ayarlama
            text_rect.x = equipment_rect.x + 10  # Sola dayalı (10 piksel içeri kaydır)
            text_rect.y = equipment_rect.y + (equipment_rect.height - text_rect.height) // 2  # Dikeyde ortalı

            # Metni ekrana çizme
            screen.blit(equipment_text, text_rect)

            # Sonraki ekipman için Y pozisyonunu güncelleme
            equipment_y += 80


    def game_over():
        """Game Over ekranını görüntüler ve oyuncuya yeniden başlama veya çıkış seçeneği sunar."""
        while True:
            screen.fill(BLACK)
            game_over_text = font.render("GAME OVER", True, RED)
            restart_text = font.render("Yeniden Başlamak İçin 'R' Tuşuna Bas", True, WHITE)
            quit_text = font.render("Çıkmak İçin 'ESC' Tuşuna Bas", True, WHITE)

            screen.blit(game_over_text, (screen_width // 2 - game_over_text.get_width() // 2, screen_height // 2 - 100))
            screen.blit(restart_text, (screen_width // 2 - restart_text.get_width() // 2, screen_height // 2))
            screen.blit(quit_text, (screen_width // 2 - quit_text.get_width() // 2, screen_height // 2 + 50))

            pygame.display.flip()

            # Olayları kontrol et
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    exit()
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_r:  # 'R' tuşuna basıldığında oyunu yeniden başlat
                        reset_game()
                        return
                    elif event.key == pygame.K_ESCAPE:  # 'ESC' tuşuna basıldığında çık
                        pygame.quit()
                        exit()


    def reset_game():
        """Oyunu yeniden başlatmak için değişkenleri sıfırlar."""
        global current_health, gold_count, character_power, equipment_owned, equipment_level, start_time
        current_health = max_health
        gold_count = 0
        character_power = 0
        equipment_owned = []
        equipment_level = 1
        start_time = time.time()  # Zamanı sıfırla


    # Sağlık yenilenmesi ve düşman hasarı arasındaki dengeyi sağlama
    now = pygame.time.get_ticks()
    if now - last_health_update >= 1000:
        current_health += health_regen_rate - enemy_damage
        if current_health > max_health:
            current_health = max_health
        elif current_health <= 0:
            game_over()  # Can sıfırlandığında Game Over ekranına geç
        last_health_update = now

    # Olayları kontrol etme
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
            running = False
        if event.type == pygame.MOUSEBUTTONDOWN:
            # Altın butonuna tıklama
            if gold_button_rect.collidepoint(event.pos):
                gold_count += click_value * click_multiplier
                total_clicks += 1
                feedback_message = random.choice(feedback_messages)

            # İşçiler butonuna tıklama
            if worker_button_rect.collidepoint(event.pos):
                show_worker_window = not show_worker_window
                show_equipment_window = False

            # Tıklama yükseltme butonuna tıklama
            if upgrade_button_rect.collidepoint(event.pos) and gold_count >= 50:
                gold_count -= 50
                click_multiplier += 1
                feedback_message = "Tıklama gücü yükseldi!"

            # Ekipman butonuna tıklama
            if equipment_button_rect.collidepoint(event.pos):
                show_equipment_window = not show_equipment_window
                show_worker_window = False

            # İşçi ve ekipman pencereleri açıkken satın alma işlemleri
            if show_worker_window:
                worker_y = worker_window_rect.y + 10
                for worker in workers:
                    worker_rect = pygame.Rect(worker_window_rect.x, worker_y, worker_window_rect.width, 60)
                    if worker_rect.collidepoint(event.pos) and gold_count >= worker["cost"]:
                        gold_count -= worker["cost"]
                        worker["count"] += 1
                        feedback_message = f"{worker['name']} işe alındı!"
                        break
                    worker_y += 80

            # Ekipman satın alındığında
            if show_equipment_window:
                equipment_y = equipment_window_rect.y + 10
                for i, name in enumerate(equipment_names):
                    equipment_rect = pygame.Rect(equipment_window_rect.x, equipment_y, equipment_window_rect.width, 60)
                    if equipment_rect.collidepoint(event.pos) and gold_count >= base_equipment_costs[i] and len(equipment_owned) == i:
                        gold_count -= base_equipment_costs[i]
                        character_power += base_equipment_powers[i]
                        equipment_owned.append(name)
                        feedback_message = f"{name} ekipmanı alındı!"
                    equipment_y += 80
                # Tüm ekipmanlar alındıysa seviyeyi yükselt
                if len(equipment_owned) == len(equipment_names):
                    level_up_equipment()
                    equipment_owned = []  # Alınan ekipmanları sıfırla

    # İşçilerin altın üretimi
    if pygame.time.get_ticks() - last_worker_update >= 1000:
        for worker in workers:
            gold_count += worker["count"] * worker["gold_per_second"]
        last_worker_update = pygame.time.get_ticks()

    # Ekranı güncelle ve FPS ayarla
    pygame.display.flip()
    clock.tick(30)

pygame.quit()



